///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//package com.mycompany.apartmentmanagementsystem;
//
///**
// *
// * @author Admin <your.name at your.org>
// */
//
//import java.sql.*;
//import javax.swing.*;
//
//public class dbConnector {
//    public static Connection mycon(){
//        try{
//            Class.forName("com.mysql.jdbc.Driver");
//            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/projectdb","root","Utkarsh@20");
//            return con;
//        }
//        catch(ClassNotFoundException | SQLException e){
//            return null;
//        }
//    }
//}